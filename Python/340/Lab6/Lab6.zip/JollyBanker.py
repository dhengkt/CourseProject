import bank

jollyBanker = bank.Bank("BankTransIn.txt")
jollyBanker.processTransaction()
jollyBanker.printResults()